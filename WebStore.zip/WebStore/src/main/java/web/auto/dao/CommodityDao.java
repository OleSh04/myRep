package web.auto.dao;


import org.springframework.data.jpa.repository.JpaRepository;

import web.auto.entity.Commodity;

public interface CommodityDao extends JpaRepository <Commodity, Integer>{
	
	
	

}
