package web.auto.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import web.auto.entity.News;

public interface NewsDao extends JpaRepository<News, Integer> {

	@Query("Select n From News n Where n.authorName Like :name")
	List<News> findByAuthor(@Param(value = "name") String name);
}
