package web.auto.dao;


import org.springframework.data.jpa.repository.JpaRepository;

import web.auto.entity.OrderOfClients;


public interface OrderOfClientsDao extends JpaRepository<OrderOfClients, Integer>{

}
