package web.auto.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import web.auto.entity.Client;

public interface ClientDao extends JpaRepository<Client, Integer> {
	
	
	@Query("Select c From Client c Where c.logIn Like :login")
	Client findByLogin(String login);
}
