package web.auto.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import web.auto.entity.Producer;

public interface ProducerDao extends JpaRepository<Producer, Integer> {

}
