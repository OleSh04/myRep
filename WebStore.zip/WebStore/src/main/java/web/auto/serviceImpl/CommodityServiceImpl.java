package web.auto.serviceImpl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import web.auto.dao.CategoryDao;
import web.auto.dao.CommodityDao;
import web.auto.dao.ProducerDao;
import web.auto.dto.CommodityImageDTO;
import web.auto.entity.Commodity;
import web.auto.service.CommodityService;

@Service
public class CommodityServiceImpl implements CommodityService {

	@Autowired
	CommodityDao commodityDao;

	@Autowired
	CategoryDao categoryDao;

	@Autowired
	ProducerDao producerDao;

	@Transactional
	public void addNewCommodity(String commodityName, String producerId, String categoryId, String comDescription,
			String price, MultipartFile file) {
		Commodity commodity = new Commodity(commodityName, producerDao.findOne(Integer.parseInt(producerId)),
				categoryDao.findOne(Integer.parseInt(categoryId)), comDescription, Integer.parseInt(price));
		commodity.setDate(new Date());
		System.out.println(commodity.getDate());
		try {
			commodity.setPicture(file.getBytes());
		} catch (IOException e) {
			System.out.println("Error");
		}
		commodityDao.save(commodity);

	}

	@Transactional
	public List<CommodityImageDTO> getAllCommodities() {
		List<Commodity> commodities = commodityDao.findAll();
		List<CommodityImageDTO> commodityImage = new ArrayList<CommodityImageDTO>();
		for (Commodity commodity : commodities) {
			CommodityImageDTO commodityImageDTO = new CommodityImageDTO(commodity.getId(), commodity.getCommodityName(),
					commodity.getPrice());
			if (commodity.getPicture() != null) {
				String image = Base64.getEncoder().encodeToString(commodity.getPicture());
				commodityImageDTO.setImage(image);
				commodityImage.add(commodityImageDTO);

			} else {
				commodityImage.add(commodityImageDTO);
			}
			

		}
		return commodityImage;
	}

}
