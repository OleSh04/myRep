package web.auto.serviceImpl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import web.auto.dao.ProducerDao;
import web.auto.entity.Producer;
import web.auto.service.ProducerService;

@Service
public class ProducerServiceImpl implements ProducerService {

	@Autowired
	private ProducerDao producerDao;

	@Transactional
	public List<Producer> showAllProducers() {
		return producerDao.findAll();
	}
	@Transactional
	public void addNewProducer(Producer producer) {
		producerDao.save(producer);
	}

}
