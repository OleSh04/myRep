package web.auto.serviceImpl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import web.auto.dao.ClientDao;
import web.auto.entity.Client;
import web.auto.service.ClientService;

@Service
public class ClientServiceImpl implements ClientService {

	@Autowired
	ClientDao clientDao;
	
	@Transactional
	public List<Client> showAllClients() {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Transactional
	public void createNewClient(String login, String password, String email, Integer phoneNumber) {
		Client client = new Client(login, email, phoneNumber, password);
		clientDao.save(client);
	}

}
