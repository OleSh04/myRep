package web.auto.serviceImpl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import web.auto.dao.CategoryDao;
import web.auto.entity.Category;
import web.auto.service.CategoryService;

@Service
public class CategoryServiceImpl implements CategoryService {

	@Autowired
	CategoryDao categoryDao;
	
	@Transactional
	public void insertCategory(String name) {
		Category category = new Category(name);
		if(name != null){
			categoryDao.save(category);
		}
		
		
	}
	@Transactional
	public List<Category> showAllCategories() {
		return categoryDao.findAll();
	}

}
