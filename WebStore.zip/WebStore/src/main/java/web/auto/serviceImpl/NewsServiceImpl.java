package web.auto.serviceImpl;

import java.util.Iterator;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import web.auto.dao.NewsDao;
import web.auto.entity.News;
import web.auto.service.NewsService;

@Service
public class NewsServiceImpl implements NewsService {

	@Autowired
	private NewsDao newsDao;

	@Transactional
	public List<News> showAllNews() {
		return newsDao.findAll();
	}

	public List<News> getallNewsByThisAuthor(String name) {

		return newsDao.findByAuthor(name);
	}

	public News findNews(String id) {
		return newsDao.findOne(Integer.parseInt(id));
	}

	public void createOrEditNews(News news) {
		System.out.println(news);
		List<News> list = newsDao.findByAuthor(news.getAuthorName());
		int i = 0;
		for (News news2 : list) {
			if (news2.getTitle().equals(news.getTitle())) {
				i++;
			}
		}

		if (i != 0) {
			for (News news2 : list) {
				if (news2.getTitle().equals(news.getTitle())) {
					System.out.println(news2);
					news2.setContent(news.getContent());
					System.out.println(news2);
					newsDao.save(news2);
				}
			}

		} else {
			newsDao.save(news);
		}

	}

	public void createNews(News news) {
		newsDao.save(news);
	}

}
