package web.auto.serviceImpl;

import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.NoResultException;
import org.springframework.transaction.annotation.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import web.auto.dao.ClientDao;
import web.auto.entity.Client;

@Service(value = "userDetailsService")
public class UserDetailsServiceImpl implements UserDetailsService {

	@Autowired
	private ClientDao clientDao;
	
	@Transactional
	public UserDetails loadUserByUsername(String login) throws UsernameNotFoundException {
		Client client = null;
		try {
			client = clientDao.findByLogin(login);
		} catch (NoResultException e) {
			return null;
		}
		
		Collection<SimpleGrantedAuthority> authorities = new ArrayList<SimpleGrantedAuthority>();
		authorities.add(new SimpleGrantedAuthority("ROLE_USER"));
		return new User(client.getLogIn(), client.getPassword(), authorities);
	}

}
