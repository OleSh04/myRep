package web.auto.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Client {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	@Column(unique = true)
	private String logIn;
	@Column
	private String email;
	@Column
	private Integer phoneNumber;
	@Column(unique = true)
	private String password;
	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "client")
	private List<OrderOfClients> orderList;

	public Client() {

	}

	public Client(String logIn, String email, Integer phoneNumber, String password) {
		this.logIn = logIn;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.password = password;
	}

	public String getLogIn() {
		return logIn;
	}

	public void setLogIn(String logIn) {
		this.logIn = logIn;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Integer getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(Integer phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public List<OrderOfClients> getOrderList() {
		return orderList;
	}

	public void setOrderList(List<OrderOfClients> orderList) {
		this.orderList = orderList;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "Client [id=" + id + ", logIn=" + logIn + ", email=" + email + ", phoneNumber=" + phoneNumber
				+ ", password=" + password + ", orderList=" + orderList + "]";
	}

	
	
}
