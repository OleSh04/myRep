package web.auto.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.Lob;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

@Entity
public class Commodity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	private String commodityName;
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private Producer producer;
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private Category category;
	@Column
	private String comDescription;
	@Column
	private Integer price;
	@Lob
	private byte [] picture;
	@Column
	private Date date;
	@Column
	private Integer buyCount;
	@ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinTable(name = "OrderCommodity", joinColumns = @JoinColumn(name = "commodityId") , inverseJoinColumns = @JoinColumn(name = "OrderId") )
	private List<OrderOfClients> orderList;

	public Commodity() {

	}

	public Commodity(String name, Integer price, String description) {
		this.commodityName = name;
		this.price = price;
	}

	public Commodity(String name, Producer producer, Category category, String comDescription,
			Integer price) {
	
		this.commodityName = name;
		this.producer = producer;
		this.category = category;
		this.comDescription = comDescription;
		this.price = price;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCommodityName() {
		return commodityName;
	}

	public void setCommodityName(String commodityName) {
		this.commodityName = commodityName;
	}

	public Producer getProducer() {
		return producer;
	}

	public void setProducer(Producer producer) {
		this.producer = producer;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public String getComDescription() {
		return comDescription;
	}

	public void setComDescription(String comDescription) {
		this.comDescription = comDescription;
	}

	public Integer getPrice() {
		return price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}

	public byte[] getPicture() {
		return picture;
	}

	public void setPicture(byte[] picture) {
		this.picture = picture;
	}

	public List<OrderOfClients> getOrderList() {
		return orderList;
	}

	public void setOrderList(List<OrderOfClients> orderList) {
		this.orderList = orderList;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Integer getBuyCount() {
		return buyCount;
	}

	public void setBuyCount(Integer buyCount) {
		this.buyCount = buyCount;
	}

	
}