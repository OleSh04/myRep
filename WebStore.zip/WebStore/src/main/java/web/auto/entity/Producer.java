package web.auto.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

@Entity
public class Producer {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	@Column
	private String pName;
	@Column
	private String Location;
	@Column
	private String pDescription;
	@ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinTable(name = "ProducerCategories", joinColumns = @JoinColumn(name = "pName") , inverseJoinColumns = @JoinColumn(name = "cName") )
	private List<Category> categoryList;
	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "producer", orphanRemoval = true)
	private List<Commodity> commodityList;

	public Producer() {

	}

	public Producer(String pName, String location, String pDescription) {
		this.pName = pName;
		Location = location;
		this.pDescription = pDescription;
	}

	public Producer(String pName, String location) {
		this.pName = pName;
		Location = location;
	}

	public Integer getId() {
		return id;
	}

	public String getpName() {
		return pName;
	}

	public void setpName(String pName) {
		this.pName = pName;
	}

	public String getLocation() {
		return Location;
	}

	public void setLocation(String location) {
		Location = location;
	}

	public String getpDescription() {
		return pDescription;
	}

	public void setpDescription(String pDescription) {
		this.pDescription = pDescription;
	}

	public List<Category> getpCategories() {
		return categoryList;
	}

	public void setpCategories(List<Category> pCategories) {
		this.categoryList = pCategories;
	}

	public List<Commodity> getpCommodity() {
		return commodityList;
	}

	public void setpCommodity(List<Commodity> pCommodity) {
		this.commodityList = pCommodity;
	}

	public List<Category> getCategoryList() {
		return categoryList;
	}

	public void setCategoryList(List<Category> categoryList) {
		this.categoryList = categoryList;
	}

	public List<Commodity> getCommodityList() {
		return commodityList;
	}

	public void setCommodityList(List<Commodity> commodityList) {
		this.commodityList = commodityList;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
	
}
