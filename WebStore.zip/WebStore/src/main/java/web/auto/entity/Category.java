package web.auto.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

@Entity
public class Category {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	@Column
	private String cName;
	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "category")
	private List<Commodity> commoditylist;
	@ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinTable(name = "ProducerCategories", joinColumns = @JoinColumn(name = "cName") , inverseJoinColumns = @JoinColumn(name = "pName") )
	private List<Producer> producerList;

	public Category() {

	}

	public Category(String cName) {
		this.cName = cName;
	}

	public String getcName() {
		return cName;
	}

	public void setcName(String cName) {
		this.cName = cName;
	}

	public List<Commodity> getCommoditylist() {
		return commoditylist;
	}

	public void setCommoditylist(List<Commodity> commoditylist) {
		this.commoditylist = commoditylist;
	}

	public List<Producer> getProducerList() {
		return producerList;
	}

	public void setProducerList(List<Producer> producerList) {
		this.producerList = producerList;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "Category [id=" + id + ", cName=" + cName + "]"; 
	}

	
}
