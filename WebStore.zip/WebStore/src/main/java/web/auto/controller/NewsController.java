package web.auto.controller;

import java.security.Principal;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import web.auto.entity.News;
import web.auto.service.NewsService;

@Controller
public class NewsController {

	@Autowired
	private NewsService newsService;

	@RequestMapping("/allNews")
	public String allNews() {
		return "news-all";
	}

	@RequestMapping("/createNews")
	public String createNews(Model model, HttpServletRequest request) {
		if (request.isUserInRole("ROLE_ADMIN")) {
			model.addAttribute("news", new News());
			return "news-new";
		} else {
			return "accessRestricted";
		}
	}
	@RequestMapping(value = "/newsCreate", method =RequestMethod.POST )
	public String newsCreate(@ModelAttribute("news") News news, Principal principal){
		news.setAuthorName(principal.getName());
		newsService.createOrEditNews(news);
		System.out.println(news);
		System.out.println(principal.getName());
		return "redirect:/adminMenu";
	}
	
		
	@RequestMapping(value="/editNews")
	public String editNews(Model model, HttpServletRequest request, Principal principal){
		if (request.isUserInRole("ROLE_ADMIN")) {
			List<News> list = newsService.getallNewsByThisAuthor(principal.getName());
			model.addAttribute("news", list);
			return "news-edit";
		} else {
			return "accessRestricted";
		}
	}
	
	@RequestMapping("/news-id={id}")
	public String News(Model model, HttpServletRequest request, @PathVariable(value = "id") String id ) {
		if (request.isUserInRole("ROLE_ADMIN")) {
			News news = newsService.findNews(id);
			model.addAttribute("news", news);
			return "news-new";
		} else {
			return "accessRestricted";
		}
	
	
	
}
}
