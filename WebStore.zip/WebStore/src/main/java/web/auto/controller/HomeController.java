package web.auto.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import web.auto.dto.CommodityImageDTO;
import web.auto.entity.Commodity;
import web.auto.service.CategoryService;
import web.auto.service.CommodityService;


@Controller
public class HomeController {

	@Autowired
	private CommodityService commodityService;
	
	@RequestMapping(value = "/")
	public String home(Model model) {
		
		List<CommodityImageDTO> commodities = commodityService.getAllCommodities();
		model.addAttribute("commodities", commodities);
		return "home";
	}

	@RequestMapping(value = "/dostavka-info")
	public String deliveryInfo() {
		return "dostavka-info";
	}

	@RequestMapping(value = "/contact-info")
	public String contactInfo() {
		return "contact-info";
	}

	@RequestMapping("/loginpage")
	public String login() {
		return "loginpage";
	}

	@RequestMapping("/adminMenu")
	public String adminMenu() {
		return "adminMenu";
	}


}

