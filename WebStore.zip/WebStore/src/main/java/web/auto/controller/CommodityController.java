package web.auto.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import web.auto.dao.CategoryDao;
import web.auto.dao.ProducerDao;
import web.auto.entity.Category;
import web.auto.entity.Commodity;
import web.auto.entity.Producer;
import web.auto.service.CategoryService;
import web.auto.service.CommodityService;
import web.auto.service.ProducerService;

@Controller
public class CommodityController {

	@Autowired
	private CommodityService commodityService;
	@Autowired
	private ProducerService producerService;
	@Autowired
	private CategoryService categoryService;

	@RequestMapping(value = "/addNewCommodity")
	public String addCommodity(Model model, HttpServletRequest httpServletRequest) {
		if (httpServletRequest.isUserInRole("ROLE_ADMIN")) {
//			Map<String, Object> map = new HashMap<String, Object>();
//			map.put("producer", producerService.showAllProducers());
//			map.put("categories", categoryService.showAllCategories());
//			model.addAllAttributes(map);
			List<Producer> producers = producerService.showAllProducers();
			List<Category> categories = categoryService.showAllCategories();
			model.addAttribute("producer", producers);
			model.addAttribute("categories", categories);
			return "new-commodity";

		} else {
			return "accessRestricted";
		}
	}

	@RequestMapping(value = "/addCommodity", method = RequestMethod.POST)
	public String Commodity(@RequestParam(value = "commodityName") String name,
			@RequestParam(value = "comDescription") String desc, 
			@RequestParam(value = "price") String price, @RequestParam(value = "producer") String producerId,
			@RequestParam(value = "category") String categoryId, @RequestParam(value = "image") MultipartFile file) {
		
		commodityService.addNewCommodity(name, producerId, categoryId,
				desc, price, file);
		return "redirect:/adminMenu";
	}

}
