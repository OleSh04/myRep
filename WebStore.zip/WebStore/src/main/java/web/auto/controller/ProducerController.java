package web.auto.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import web.auto.dao.CategoryDao;
import web.auto.entity.Category;
import web.auto.entity.Producer;
import web.auto.service.CategoryService;
import web.auto.service.ProducerService;

@Controller
public class ProducerController {

	@Autowired
	private ProducerService producerService;

	@Autowired
	private CategoryService categoryService;

	@RequestMapping(value = "/addNewProducer")
	public String newProducerPage(Model model) {
		List<Category> categories = categoryService.showAllCategories();
		
		Producer producer = new Producer();
		producer.setCategoryList(categories);
		
		model.addAttribute("producer", producer);

		return "producer-new";
	}

	@RequestMapping(value = "/createProducer", method = RequestMethod.POST)
	public String createProducer(@ModelAttribute(value = "producer") Producer producer){
		producerService.addNewProducer(producer);
		return "redirect:/adminPage";
	}
}
