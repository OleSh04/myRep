package web.auto.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import web.auto.entity.Client;
import web.auto.service.ClientService;

@Controller
public class ClientController {

	@Autowired
	ClientService clientService;
	
	@RequestMapping("/registration")
	public String newUser(Model model) {
		model.addAttribute("client", new Client());
		return "registration";
	}

	@RequestMapping(value = "/createUser", method = RequestMethod.POST)
	public String commitNewUser(
			@ModelAttribute(value="client") Client client){
			clientService.createNewClient(client.getLogIn(), client.getPassword(), client.getEmail(), client.getPhoneNumber());
	
		return "redirect:/loginpage";
}
}