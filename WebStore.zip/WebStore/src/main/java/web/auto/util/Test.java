package web.auto.util;

import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;


public class Test extends LocalContainerEntityManagerFactoryBean{

	
	
}
