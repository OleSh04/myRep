package web.auto.util;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;

import web.auto.entity.Category;
import web.auto.entity.Producer;

public class Main {


	
	
	
	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("hello");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		Producer producer = entityManager.find(Producer.class, 1);
		System.out.println(producer.getpCategories());
		entityManager.getTransaction().commit();
		
//		producer.setpCategories(null);
	}

}
