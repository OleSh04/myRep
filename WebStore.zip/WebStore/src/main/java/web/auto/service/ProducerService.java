package web.auto.service;

import java.util.List;

import web.auto.entity.Category;
import web.auto.entity.Producer;

public interface ProducerService {

	List<Producer> showAllProducers();
	
	void addNewProducer(Producer producer);
}
