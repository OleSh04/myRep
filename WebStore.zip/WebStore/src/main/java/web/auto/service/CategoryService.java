package web.auto.service;

import java.util.List;

import web.auto.entity.Category;

public interface CategoryService {

void insertCategory(String name);
	
	List<Category> showAllCategories();
	
}
