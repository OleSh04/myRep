package web.auto.service;

import java.util.List;

import web.auto.entity.News;

public interface NewsService {

	List<News> showAllNews();
	
	void createOrEditNews(News news);
	
	void createNews(News news);
	
	List<News> getallNewsByThisAuthor( String name);
	
	News findNews(String id);
}
