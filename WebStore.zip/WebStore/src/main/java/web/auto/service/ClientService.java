package web.auto.service;

import java.util.List;

import web.auto.entity.Client;

public interface ClientService {

	List<Client> showAllClients();
	
	void createNewClient(String login, String password, String email, Integer phoneNumber);
}
