package web.auto.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import web.auto.dto.CommodityImageDTO;
import web.auto.entity.Category;
import web.auto.entity.Commodity;
import web.auto.entity.Producer;

public interface CommodityService {
	

	void addNewCommodity(String name, String producerId, String categoryId, String desc, String price, MultipartFile file);
	
	List<CommodityImageDTO> getAllCommodities();
	
}
